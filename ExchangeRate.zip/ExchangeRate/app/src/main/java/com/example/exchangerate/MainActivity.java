package com.example.exchangerate;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private Document doc;
    private Thread secThread;
    private Runnable runnable;
    private ListView listView;
    private CustomArrayAdapter adapter;
    private List<ListItemClass> arrayList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
    }
    private void init()
    {
        listView = findViewById(R.id.listView);
        arrayList = new ArrayList<>();
        adapter = new CustomArrayAdapter(this,R.layout.list_item_1,arrayList,getLayoutInflater());
        listView.setAdapter(adapter);
        runnable = new Runnable() {
            @Override
            public void run() {
                getWeb();
            }
        };
        secThread = new Thread(runnable);
        secThread.start();
        /* ListItemClass items = new ListItemClass();
        items.setData_1("Dollar");
        items.setData_2("78");
        arrayList.add(items);
        items = new ListItemClass();
        items.setData_1("Euro");
        items.setData_2("89");
        arrayList.add(items);
        adapter.notifyDataSetChanged(); */

    }
    private void getWeb()
    {
        try {
            doc = Jsoup.connect("https://www.cbr.ru/currency_base/daily/").get();
            Elements tables = doc.getElementsByTag("tbody");
            Element our_table = tables.get(0);
            Elements elements_from_table = our_table.children();
            Element australian_dollar = elements_from_table.get(1);
            Elements australian_dollar_elements = australian_dollar.children();
            Log.d("MyLog", "Tbody size : " + our_table.children().get(1).text());
            for(int i = 0;i < 1;i++ )
            {
                ListItemClass items = new ListItemClass();
                items.setData_1(our_table.children().get(i).child(3).text());
                items.setData_2(our_table.children().get(i).child(4).text());
                arrayList.add(items);
            }
            for(int i = 1;i < 2;i++ )
            {
                ListItemClass items = new ListItemClass();
                items.setData_1(our_table.children().get(i).child(3).text());
                items.setData_2(our_table.children().get(i).child(4).text());
                arrayList.add(items);
            }
            for(int i = 4;i < 7;i++ )
            {
                ListItemClass items = new ListItemClass();
                items.setData_1(our_table.children().get(i).child(3).text());
                items.setData_2(our_table.children().get(i).child(4).text());
                arrayList.add(items);
            }
            for(int i = 10;i < 13;i++ )
            {
                ListItemClass items = new ListItemClass();
                items.setData_1(our_table.children().get(i).child(3).text());
                items.setData_2(our_table.children().get(i).child(4).text());
                arrayList.add(items);
            }
            for(int i = 15;i < 16;i++ )
            {
                ListItemClass items = new ListItemClass();
                items.setData_1(our_table.children().get(i).child(3).text());
                items.setData_2(our_table.children().get(i).child(4).text());
                arrayList.add(items);
            }
            for(int i = 17;i < 18;i++ )
            {
                ListItemClass items = new ListItemClass();
                items.setData_1(our_table.children().get(i).child(3).text());
                items.setData_2(our_table.children().get(i).child(4).text());
                arrayList.add(items);
            }
            for(int i = 21;i < 23;i++ )
            {
                ListItemClass items = new ListItemClass();
                items.setData_1(our_table.children().get(i).child(3).text());
                items.setData_2(our_table.children().get(i).child(4).text());
                arrayList.add(items);
            }
            for(int i = 24;i < 25;i++ )
            {
                ListItemClass items = new ListItemClass();
                items.setData_1(our_table.children().get(i).child(3).text());
                items.setData_2(our_table.children().get(i).child(4).text());
                arrayList.add(items);
            }
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    adapter.notifyDataSetChanged();
                }
            });



        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}